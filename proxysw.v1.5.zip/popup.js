document.addEventListener('DOMContentLoaded', function() {
  // 从存储中加载代理配置
  chrome.storage.sync.get(['proxyAddress', 'proxyPort', 'isEnabled', 'savedProxies'], function(data) {
    if (data.proxyAddress) document.getElementById('proxyAddress').value = data.proxyAddress;
    if (data.proxyPort) document.getElementById('proxyPort').value = data.proxyPort;
    updateButtonState(data.isEnabled);
    updateSavedProxies(data.savedProxies || []);
  });

  // 切换代理按钮点击事件
  document.getElementById('toggleButton').addEventListener('click', function() {
    const proxyAddress = document.getElementById('proxyAddress').value.trim();
    const proxyPort = document.getElementById('proxyPort').value.trim();
    const isEnabled = document.getElementById('toggleButton').textContent === '启用代理';

    if (isEnabled) {
      // 启用代理
      if (!proxyAddress || !proxyPort) {
        alert('请填写代理地址和端口');
        return;
      }

      chrome.storage.sync.set({
        proxyAddress: proxyAddress,
        proxyPort: proxyPort,
        isEnabled: true
      });

      const proxyConfig = {
        mode: 'fixed_servers',
        rules: {
          singleProxy: {
            scheme: 'http',
            host: proxyAddress,
            port: parseInt(proxyPort)
          },
          bypassList: ['localhost']
        }
      };

      chrome.proxy.settings.set({ value: proxyConfig, scope: 'regular' }, function() {
        updateButtonState(true);
      });
    } else {
      // 禁用代理
      chrome.storage.sync.set({ isEnabled: false });
      chrome.proxy.settings.clear({ scope: 'regular' }, function() {
        updateButtonState(false);
      });
    }
  });

  // 保存当前配置
  document.getElementById('saveButton').addEventListener('click', function() {
    const proxyAddress = document.getElementById('proxyAddress').value.trim();
    const proxyPort = document.getElementById('proxyPort').value.trim();
    const saveName = document.getElementById('saveName').value.trim();

    if (!proxyAddress || !proxyPort || !saveName) {
      alert('请填写代理地址、端口和保存名称');
      return;
    }

    chrome.storage.sync.get(['savedProxies'], function(data) {
      const savedProxies = data.savedProxies || [];
      savedProxies.push({ name: saveName, address: proxyAddress, port: proxyPort });
      chrome.storage.sync.set({ savedProxies: savedProxies }, function() {
        alert('配置已保存');
        updateSavedProxies(savedProxies);
      });
    });
  });

  // 删除选中配置
  document.getElementById('deleteButton').addEventListener('click', function() {
    const selectedProxy = document.getElementById('savedProxies').value;
    if (!selectedProxy) {
      alert('请选择要删除的配置');
      return;
    }

    chrome.storage.sync.get(['savedProxies'], function(data) {
      const savedProxies = data.savedProxies || [];
      const filteredProxies = savedProxies.filter(proxy => proxy.name !== selectedProxy);
      chrome.storage.sync.set({ savedProxies: filteredProxies }, function() {
        alert('配置已删除');
        updateSavedProxies(filteredProxies);
      });
    });
  });

  // 从保存的配置中加载
  document.getElementById('savedProxies').addEventListener('change', function() {
    const selectedProxy = this.value;
    if (!selectedProxy) return;

    chrome.storage.sync.get(['savedProxies'], function(data) {
      const savedProxies = data.savedProxies || [];
      const selected = savedProxies.find(proxy => proxy.name === selectedProxy);
      if (selected) {
        document.getElementById('proxyAddress').value = selected.address;
        document.getElementById('proxyPort').value = selected.port;
        document.getElementById('saveName').value = selected.name;
      }
    });
  });

  // 更新按钮状态
  function updateButtonState(isEnabled) {
    const button = document.getElementById('toggleButton');
    const status = document.getElementById('status');

    if (isEnabled) {
      button.textContent = '禁用代理';
      status.textContent = '当前状态: 已启用';
      status.className = 'status enabled';
    } else {
      button.textContent = '启用代理';
      status.textContent = '当前状态: 未启用';
      status.className = 'status disabled';
    }
  }

  // 更新保存的代理列表
  function updateSavedProxies(proxies) {
    const select = document.getElementById('savedProxies');
    select.innerHTML = '<option value="">-- 选择保存的代理 --</option>';
    
    proxies.forEach(proxy => {
      const option = document.createElement('option');
      option.value = proxy.name;
      option.textContent = proxy.name;
      select.appendChild(option);
    });
  }
});