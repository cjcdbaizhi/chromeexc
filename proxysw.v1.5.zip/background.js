chrome.proxy.onProxyConfigChanged.addListener(function() {
  // 当代理配置发生变化时，更新存储
  chrome.proxy.settings.get({ incognito: false }, function(config) {
    if (config.value && config.value.mode === 'fixed_servers') {
      const proxy = config.value.rules.singleProxy;
      chrome.storage.sync.set({
        proxyAddress: proxy.host,
        proxyPort: proxy.port,
        isEnabled: true
      });
    } else {
      chrome.storage.sync.set({ isEnabled: false });
    }
  });
});